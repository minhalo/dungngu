import { Component, OnInit } from '@angular/core';
import { TodoService, Todo } from '../../services/todo.service';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.scss'],
})
export class MainComponent implements OnInit {
  name: string = 'John';
  googleURL: string = 'https://www.google.com/';
  colSpan: number = 2;
  count: number = 0;
  selectedNavTab: string = 'tab1';
  userName: string = 'John Doe';
  newTodo: string = '';
  todos: Todo[] = [];

  price: number = 9.99;

  today: Date = new Date();

  constructor(private todoService: TodoService) {}

  ngOnInit(): void {
    this.todoService.getAllTodos().subscribe((res: Todo[]) => {
      this.todos = res;
    });
  }

  selectTab(value) {
    this.selectedNavTab = value;
  }

  increase(event) {
    console.log(event);
    // this.count = this.count + 1;
    this.count += 1;
  }

  decrease() {
    // this.count = this.count - 1;
    this.count -= 1;
  }

  getTitle() {
    return 'Count: ';
  }

  onBlur() {
    console.log(this.userName);
  }

  addNewTodo(input?) {
    // console.log(input.value);
    var newTodo = {
      userId: 1,
      title: this.newTodo,
      completed: false,
    };
    this.newTodo = '';
    this.todoService.addNewTodo(newTodo).subscribe(
      (res: Todo) => {
        this.todos.unshift(res);
      },
      (err) => {}
    );
  }

  deleteTodo(index) {
    this.todoService.deleteTodo(this.todos[index].id).subscribe(
      (res) => {
        this.todos.splice(index, 1);
      },
      (err) => {}
    );
  }

  toogleTodo(i) {
    this.todos[i].completed = !this.todos[i].completed;
  }
}
